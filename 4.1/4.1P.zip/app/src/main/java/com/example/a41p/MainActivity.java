package com.example.a41p;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private long pauseOffset;
    private String runningTime;
    Chronometer chronometer;
    private boolean running;
    String TASK;

    private TextView lastTimerSave;
    private EditText enterTask;

    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chronometer = findViewById(R.id.chronometer);
        lastTimerSave = findViewById(R.id.lastTimerSave);
        enterTask = findViewById(R.id.enterTask);
        sharedPreferences = getSharedPreferences("com.example.a41p", MODE_PRIVATE);
        checkSharedPreferences();
        if(savedInstanceState != null){
            if (savedInstanceState.getBoolean("Running")) {
                chronometer.setBase(savedInstanceState.getLong("ChronoTime") - savedInstanceState.getLong("Offset"));
                chronometer.start();
                running = true;
            }
        }

    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putLong("ChronoTime", chronometer.getBase());
        outState.putBoolean("Running", running);
        outState.putLong("Offset", pauseOffset);
    }

    public void startTimer(View v) {
        // If chronometer is not running, start and set boolean true
        if(!running) {
            // Pass milliseconds of operation that have elapsed since boot whilst subtracting pausedTime
            chronometer.setBase(SystemClock.elapsedRealtime() - pauseOffset);
            chronometer.start();
            running = true;
        }
    }

    public void pauseTimer(View v) {
        // If chronometer is running, pause and set boolean false
        if(running) {
            // Stop elapsed real time
            chronometer.stop();
            //Set variable to elapsed real time subtracted by when the timer has stopped
            //Meaning the chronometer will display the paused time
            pauseOffset = SystemClock.elapsedRealtime() - chronometer.getBase();
            running= false;
        }
    }

    public void stopTimer(View v) {
        // Save current time whilst resetting back to 0 for new task.
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(TASK, enterTask.getText().toString());
        editor.apply();
        editor.putString("runningTime", chronometer.getText().toString());
        editor.apply();
        chronometer.setBase(SystemClock.elapsedRealtime());
        pauseOffset = 0;
        chronometer.stop();
    }
    public void checkSharedPreferences(){
        String task = sharedPreferences.getString(TASK, "");
        runningTime = sharedPreferences.getString("runningTime", "");

        lastTimerSave.setText("You spent " + runningTime + " on " + task + " last time");

    }
}
