package com.example.a51c;

public class News {
    private int id;
    private String newsTitle;
    private String newsDescription;
    private int newsLogo;

    public News(int id, int newsLogo, String newsTitle, String newsDescription)
    {
        this.id = id;
        this.newsLogo = newsLogo;
        this.newsTitle = newsTitle;
        this.newsDescription = newsDescription;
    }
    public int getId() {
        return id;
    }

    public void setId (int id) {
        this.id = id;
    }
    public int getNewsLogo() {
        return newsLogo;
    }

    public String getNewsTitle() {
        return newsTitle;
    }

    public void setNewsLogo (int newsLogo) {
        this.newsLogo = newsLogo;
    }

    public void setNewsName (String newsTitle) {
        this.newsTitle = newsTitle;
    }

    public String getNewsDescription() {
        return newsDescription;
    }

    public void setNewsDescription (String newsDescription) {
        this.newsDescription = newsDescription;
    }
}
