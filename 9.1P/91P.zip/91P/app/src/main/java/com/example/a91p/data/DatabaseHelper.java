package com.example.a91p.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.a91p.model.Advert;
import com.example.a91p.util.Util;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    public DatabaseHelper(@Nullable Context context) {
        super(context, Util.DATABASE_NAME, null, Util.DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        String CREATE_USER_TABLE = "CREATE TABLE " + Util.TABLE_NAME + "(" + Util.ADVERT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT , " + " TEXT," + Util.NAME + " TEXT," + Util.DESCRIPTION
                + " TEXT," + Util.LOCATION + " TEXT," + Util.PHONE + " TEXT,"
                + Util.DATE + " TEXT," + Util.TYPE + " TEXT," + Util.LONG + " TEXT," + Util.LAT + ");";

        sqLiteDatabase.execSQL(CREATE_USER_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        String DROP_USER_TABLE = "DROP TABLE IF EXISTS ";
        sqLiteDatabase.execSQL(DROP_USER_TABLE + Util.TABLE_NAME);

        onCreate(sqLiteDatabase);
    }

    public long insertAdvert (Advert advert)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Util.NAME, advert.getName());
        contentValues.put(Util.DESCRIPTION, advert.getDescription());
        contentValues.put(Util.LOCATION, advert.getLocation());
        contentValues.put(Util.PHONE, advert.getPhone());
        contentValues.put(Util.DATE, advert.getDate());
        contentValues.put(Util.TYPE, advert.getType());
        contentValues.put(Util.LAT, advert.getLat());
        contentValues.put(Util.LONG, advert.getLang());
        long newRowId = db.insertOrThrow(Util.TABLE_NAME, null, contentValues);
        db.close();
        return newRowId;
    }

    public List<Advert> FetchAllAdverts (){
        List<Advert> advertList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String selectAll = " SELECT * FROM " + Util.TABLE_NAME;
        // Allow the cursor to access all rows of data
        Cursor cursor = db.rawQuery(selectAll, null);
        if(cursor.moveToFirst()) {
            do {
                // Get all information for current advert
                Advert advert = new Advert();
                advert.setAdvert_id(cursor.getInt(0 ));
                advert.setName(cursor.getString(2));
                advert.setDescription(cursor.getString(3));
                advert.setLocation(cursor.getString(4));
                advert.setPhone(cursor.getString(5));
                advert.setDate(cursor.getString(6));
                advert.setType(cursor.getString(7));
                advert.setLat(cursor.getDouble(9));
                advert.setLong(cursor.getDouble(8));

                // Add to advertList
                advertList.add(advert);

            }while (cursor.moveToNext()); //Iterate while there is another advert
        }

        return advertList;
    }

    public void deleteRow(String name)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(Util.TABLE_NAME, "advert_name = ?", new String[]{name});
        db.close();
    }
}
