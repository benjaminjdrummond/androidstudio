package com.example.a91p.util;

public class Util {

    public static final int DATABASE_VERSION = 8;
    public static final String ADVERT_ID = "advert_id";
    public static final String DATABASE_NAME = "advert_database";
    public static final String TABLE_NAME = "adverts";
    public static final String NAME = "advert_name";
    public static final String DESCRIPTION = "advert_description";
    public static final String LOCATION = "advert_location";
    public static final String PHONE = "advert_phone";
    public static final String DATE = "advert_date";
    public static final String TYPE = "advert_type";
    public static final String LONG = "advert_long";
    public static final String LAT = "advert_lat";


}
