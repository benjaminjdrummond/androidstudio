package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class QuizEnd extends AppCompatActivity {

    Button buttonFinish, buttonRestart;
    TextView endName;
    EditText userScore;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_end);

        // Get username and score from previous activity
        Intent intent = getIntent();
        //Bundle bundle1 = intent.getExtras();
        String userName = intent.getStringExtra("username");
        int score = intent.getIntExtra("score", 0);

        buttonFinish = findViewById(R.id.buttonFinish);
        buttonRestart = findViewById(R.id.buttonRestart);

        endName = findViewById(R.id.endName);
        userScore = findViewById(R.id.userScore);

        // Set finish messages
        endName.setText("Congratulations " + userName + "!");
        userScore.setText(score+"/10");

        buttonFinish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finishAffinity();
            }
        });

        buttonRestart.setOnClickListener(new View.OnClickListener() {
            @Override
            //Restart but keep username in field
            public void onClick(View view) {
                Intent intent2 = new Intent(getApplicationContext(), MainActivity.class);
                intent2.putExtra("username", userName);
                intent.setFlags(Intent.FLAG_ACTIVITY_FORWARD_RESULT);
                setResult(RESULT_OK, intent2);
                finish();

            }
        });
    }
}