package com.example.a51c;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class topNewsAdapter extends RecyclerView.Adapter<topNewsAdapter.ViewHolder>
{

    private List<topModel> topList;
    private Context context;
    private OnNoteListener topNoteListener;

    public topNewsAdapter(List<topModel> topList, Context context, OnNoteListener onNoteListener) {
        this.topList = topList;
        this.context = context;
        this.topNoteListener = onNoteListener;
    }


    @NonNull
    @Override
    public topNewsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context)
                .inflate(R.layout.top_news_row, parent, false);
        return new ViewHolder(itemView, topNoteListener);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        //holder.topnewstext.setText(topList.get(position).getTopName());
        holder.topLogoImage.setImageResource(topList.get(position).getTopLogo());
    }

    @Override
    public int getItemCount() {
        return topList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public ImageView topLogoImage;
        public TextView topnewstext;
        public Button topLogoButton;

        OnNoteListener onNoteListener;
        public ViewHolder(@NonNull View itemView, OnNoteListener onNoteListener) {
            super(itemView);
            topLogoImage = itemView.findViewById(R.id.newsLogo2);
            this.onNoteListener = onNoteListener;

            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            onNoteListener.onNoteClick(getAdapterPosition());
        }
    }

    public interface OnNoteListener{
        void onNoteClick(int position);
    }
}
