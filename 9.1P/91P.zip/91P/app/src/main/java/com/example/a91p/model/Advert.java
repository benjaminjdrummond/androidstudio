package com.example.a91p.model;

public class Advert {
    private int advert_id;
    private String name;
    private String description;
    private String location;
    private String type;
    private String phone;
    private String date;
    private Double lang;
    private Double lat;

    public Double getLang() {
        return lang;
    }

    public void setLong(Double lang) {
        this.lang = lang;
    }

    public Double getLat() {
        return lat;
    }

    public void setLat(Double lat) {
        this.lat = lat;
    }

    public Advert(String name, String description, String location, String phone, String date, String type, Double lang, Double lat) {
        this.name = name;
        this.description = description;
        this.location = location;
        this.phone = phone;
        this.date = date;
        this.type = type;
        this.lang = lang;
        this.lat = lat;
    }

    public Advert() {
    }

    public int getAdvert_id() { return advert_id;}

    public void setAdvert_id(int advert_id) {this.advert_id = advert_id;}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
