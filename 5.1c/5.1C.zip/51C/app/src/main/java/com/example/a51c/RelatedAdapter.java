package com.example.a51c;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.BreakIterator;
import java.util.List;

public class RelatedAdapter extends RecyclerView.Adapter<RelatedAdapter.ViewHolder>
{

    private List<News> relatedList;
    private Context context;
    private RelatedNoteListener relatedNoteListener;

    public RelatedAdapter(List<News> relatedList, Context context, RelatedNoteListener relatedNoteListener) {
        this.relatedList = relatedList;
        this.context = context;
        this.relatedNoteListener = relatedNoteListener;
    }


    @NonNull
    @Override
    public RelatedAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context)
                .inflate(R.layout.relatednews, parent, false);
        return new ViewHolder(itemView, relatedNoteListener);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.relatedTitle.setText(relatedList.get(position).getNewsTitle());
        holder.relatedLogo.setImageResource(relatedList.get(position).getNewsLogo());
        holder.relatedDesc.setText(relatedList.get(position).getNewsDescription());
    }

    @Override
    public int getItemCount() {
        return relatedList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public ImageView relatedLogo;
        public TextView relatedTitle, relatedDesc;


        RelatedNoteListener relatedNoteListener;
        public ViewHolder(@NonNull View itemView, RelatedNoteListener relatedNoteListener) {
            super(itemView);
            relatedTitle = itemView.findViewById(R.id.relatedTitle);
            relatedLogo = itemView.findViewById(R.id.relatedLogo);
            relatedDesc = itemView.findViewById(R.id.relatedDesc);
            this.relatedNoteListener = relatedNoteListener;

            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {  relatedNoteListener.relatedNoteClick(getAdapterPosition()); }

        }
    public interface RelatedNoteListener{
        void relatedNoteClick(int position);
    }
}
