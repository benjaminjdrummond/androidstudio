package com.example.a51c;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link EgFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class BleachFragment extends Fragment implements RelatedAdapter.RelatedNoteListener{

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    RelatedAdapter relatedAdapter;
    private RecyclerView relatedView;
    private List<News> relatedList = new ArrayList<>();
    private int[] relatedLogo = {R.drawable.aot};
    private String[] relatedName = {"AOT S4P3 announced"};
    private String[] relatedDesc = {"Part 3 of the final season to Attack on Titan has been announced recently, and people everywhere are pondering why it was called the final season in the first place. Nevertheless, anticipation is at it's highest after a wonderful season."};

    public BleachFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment EgFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static BleachFragment newInstance(String param1, String param2) {
        BleachFragment fragment = new BleachFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate layout for this fragment
        View view = inflater.inflate(R.layout.fragment_depp, container, false);
        ImageView imageView = (ImageView) view.findViewById(R.id.fragImage);
        TextView title = (TextView) view.findViewById(R.id.fragTitle);
        TextView desc = (TextView) view.findViewById(R.id.fragDesc);
        imageView.setBackgroundResource(R.drawable.bleach);
        title.setText("Bleach return");
        desc.setText("After taking a 10 year break, the anime known as 'Bleach' by Tite Kubo will be returning with the Thousand-Year Blood War arc. Fans are left wondering how well it will be made given the track record of Studio Pierrot.");

        //Implement data
        for (int j = 0; j < relatedName.length; j++){
            News relatedModel = new News(j, relatedLogo[j], relatedName[j], relatedDesc[j]);
            relatedList.add(relatedModel);

        }
        // Assign ids for news
        relatedView = (RecyclerView) view.findViewById(R.id.relatedView);
        relatedView.setLayoutManager(new LinearLayoutManager(getActivity()));
        relatedAdapter = new RelatedAdapter(relatedList, view.getContext(), this);
        relatedView.setAdapter(relatedAdapter);
        relatedView.setItemAnimator(new DefaultItemAnimator());
        return view;

    }

    @Override
    public void relatedNoteClick(int position) {
        selectFragment(position);
    }

    private void selectFragment(int position) {
        Fragment fragment;
        switch(position)
        {
            case 0:
                fragment = new AOTFragment();
                break;

            default:
                throw new IllegalStateException("Unexpected position: " + position);

        }
        // Select fragment for current news item selected
        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragmentContainerView, fragment).addToBackStack(null).commit();
    }
}