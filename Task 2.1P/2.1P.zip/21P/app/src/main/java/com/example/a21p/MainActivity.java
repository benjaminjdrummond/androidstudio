package com.example.a21p;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.icu.text.DecimalFormat;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

@RequiresApi(api = Build.VERSION_CODES.N)
public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    ImageButton lengthButton;
    ImageButton tempButton;
    ImageButton weightButton;

    TextView resultOneText;
    TextView resultTwoText;
    TextView resultThreeText;

    EditText conversionEditText;

    DecimalFormat df = new DecimalFormat("###.##");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner spinner = findViewById(R.id.spinner1);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.objects, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);

        resultOneText = findViewById(R.id.resultOneText);
        resultTwoText = findViewById(R.id.resultTwoText);
        resultThreeText = findViewById(R.id.resultThreeText);

        conversionEditText = findViewById(R.id.conversionEditText);

        lengthButton = (ImageButton)findViewById(R.id.lengthButton);
        lengthButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String current = spinner.getSelectedItem().toString();
                if (current.equals("Metre")){
                    float centimetre = (float) Float.parseFloat(conversionEditText.getText().toString()) * 100;
                    resultOneText.setText(df.format(centimetre) + " Centimetres");

                    float foot = (float) (Float.parseFloat(conversionEditText.getText().toString()) * 3.28084);
                    resultTwoText.setText(df.format(foot) + " Feet");

                    float inch = (float) (Float.parseFloat(conversionEditText.getText().toString()) * 39.37);
                    resultThreeText.setText(df.format(inch) + " Inches");
                }
                else{
                    Toast.makeText(getApplicationContext(), "Please select the correct conversion icon", Toast.LENGTH_SHORT).show();
                }
            }
        });

        tempButton = (ImageButton)findViewById(R.id.tempButton);
        tempButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String current = spinner.getSelectedItem().toString();
                if (current.equals("Celsius")) {
                    float fahrenheit = (float) (Float.parseFloat(conversionEditText.getText().toString()) * 1.8 + 32);
                    resultOneText.setText(df.format(fahrenheit) + " Fahrenheit");

                    float kelvin = (float) (Float.parseFloat(conversionEditText.getText().toString()) + 273.15);
                    resultTwoText.setText(df.format(kelvin) + " Kelvin");

                    resultThreeText.setText("");
                }
                else{
                    Toast.makeText(getApplicationContext(), "Please select the correct conversion icon", Toast.LENGTH_SHORT).show();
                }
            }
        });

        weightButton = (ImageButton)findViewById(R.id.weightButton);
        weightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String current = spinner.getSelectedItem().toString();
                if (current.equals("Kilograms")) {
                    float gram = (float) (Float.parseFloat(conversionEditText.getText().toString()) * 1000);
                    resultOneText.setText(df.format(gram) + " Gram");

                    float ounce = (float) (Float.parseFloat(conversionEditText.getText().toString()) * 35.2739619);
                    resultTwoText.setText(df.format(ounce) + " Ounce(Oz)");

                    float pound = (float) (Float.parseFloat(conversionEditText.getText().toString()) * 2.20462);
                    resultThreeText.setText(df.format(pound) + " Pound(lb)");
                }
                else{
                    Toast.makeText(getApplicationContext(), "Please select the correct conversion icon", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        String text = adapterView.getItemAtPosition(i).toString();
        Toast.makeText(adapterView.getContext(),text, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}