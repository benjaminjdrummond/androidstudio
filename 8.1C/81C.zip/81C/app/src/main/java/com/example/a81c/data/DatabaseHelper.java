package com.example.a81c.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.a81c.User.User;
import com.example.a81c.User.Video;
import com.example.a81c.util.Util;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    public DatabaseHelper(@Nullable Context context) {
        super(context, Util.DATABASE_NAME, null, Util.DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        String CREATE_USER_TABLE = "CREATE TABLE " + Util.TABLE_NAME + "(" + Util.USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT , " + Util.NAME +
                " TEXT," + Util.PASSWORD + ");";

        sqLiteDatabase.execSQL(CREATE_USER_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        String DROP_USER_TABLE = "DROP TABLE IF EXISTS ";
        sqLiteDatabase.execSQL(DROP_USER_TABLE + Util.TABLE_NAME);

        onCreate(sqLiteDatabase);
    }

    public long insertUser (User user)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Util.NAME, user.getUsername());
        contentValues.put(Util.PASSWORD, user.getPassword());

        long newRowId = db.insertOrThrow(Util.TABLE_NAME, null, contentValues);
        db.close();
        return newRowId;
    }

    public List<User> FetchAllUsers (){
        List<User> userList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String selectAll = " SELECT * FROM " + Util.TABLE_NAME;
        // Allow the cursor to access all rows of data
        Cursor cursor = db.rawQuery(selectAll, null);
        if(cursor.moveToFirst()) {
            do {
                // Get all information for current advert
                User user = new User();
                user.setUserid(cursor.getInt(0 ));
                user.setUsername(cursor.getString(2));
                user.setPassword(cursor.getString(3));


                // Add to advertList
                userList.add(user);

            }while (cursor.moveToNext()); //Iterate while there is another advert
        }

        return userList;
    }

    public void deleteRow(String name)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(Util.TABLE_NAME, "advert_name = ?", new String[]{name});
        db.close();
    }

    public boolean fetchUser(String username, String password)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(Util.TABLE_NAME, new String[]{Util.USER_ID}, Util.NAME + "=? and " + Util.PASSWORD + "=?",
                new String[] {username, password}, null, null, null);
        int numberOfRows = cursor.getCount();
        db.close();

        if (numberOfRows > 0)
            return  true;
        else
            return false;
    }
}
