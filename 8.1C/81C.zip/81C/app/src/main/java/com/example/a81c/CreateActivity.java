package com.example.a81c;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.a81c.data.DatabaseHelper;
import com.example.a81c.User.User;

public class CreateActivity extends AppCompatActivity {

    DatabaseHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);
        Button saveButton = findViewById(R.id.saveButton);
        EditText fullNameView = findViewById(R.id.fullnameText);
        EditText nameView = findViewById(R.id.usernameText);
        EditText passView = findViewById(R.id.passwordText);
        EditText confirmView = findViewById(R.id.confirmpassText);

        db = new DatabaseHelper(getApplicationContext());

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    String userFullname = fullNameView.getText().toString();
                    String userName = nameView.getText().toString();
                    String userPass = passView.getText().toString();
                    String confirmUserPass = confirmView.getText().toString();
                    if(TextUtils.isEmpty(userFullname) || TextUtils.isEmpty(userName) || TextUtils.isEmpty(userPass) || TextUtils.isEmpty(confirmUserPass))
                    {
                        Toast.makeText(CreateActivity.this, "Empty field", Toast.LENGTH_SHORT).show();
                    }

                    else
                    {
                        if (userPass.equals(confirmUserPass))
                        {
                            long result = db.insertUser(new User(userName, userPass));
                            if (result > 0)
                            {
                                Toast.makeText(CreateActivity.this, "Account created", Toast.LENGTH_SHORT).show();
                            }
                            else
                            {
                                Toast.makeText(CreateActivity.this, "Creation error!", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else
                        {
                            Toast.makeText(CreateActivity.this, "Passwords do not match!", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
        });
    }
}