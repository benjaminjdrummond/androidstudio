package com.example.a81c.util;

public class Util {

    public static final int DATABASE_VERSION = 9;
    public static final String USER_ID = "user_id";
    public static final String DATABASE_NAME = "user_database";
    public static final String TABLE_NAME = "users";
    public static final String NAME = "user_name";
    public static final String PASSWORD = "user_password";

    public static final String VIDEOTABLE_NAME = "videos";
    public static final String LINK = "video";
    public static final String PLAYLIST ="playlist_id";


}
