package com.example.a91p;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.a91p.data.DatabaseHelper;
import com.example.a91p.model.Advert;

import java.util.ArrayList;
import java.util.List;

public class ShowAdvertsActivity extends AppCompatActivity {

    ListView advertListView;
    ArrayList<String> advertArrayList;

    // Implement adapter
    ArrayAdapter<String> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_adverts);

        advertListView = findViewById(R.id.advertsListView);
        advertArrayList = new ArrayList<>();
        DatabaseHelper db = new DatabaseHelper(getApplicationContext());

        List<Advert> advertList = db.FetchAllAdverts();

        // Iterate through advertList
        // Go through by key : value
        for (Advert advert : advertList)
        {
            advertArrayList.add(advert.getType() + " " + advert.getName());
        }

        // Create adapter
        arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, advertArrayList);
        // Set adapter to listview to populate
        advertListView.setAdapter(arrayAdapter);

        //List view on click
        advertListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                // Send bundle of data
                Advert advert = advertList.get(i);
                Bundle bundle = new Bundle();
                bundle.putInt("id", advert.getAdvert_id());
                bundle.putString("name", advert.getName());
                bundle.putString("desc", advert.getDescription());
                bundle.putString("phone", advert.getPhone());
                bundle.putString("date", advert.getDate());
                bundle.putString("type", advert.getType());
                bundle.putString("location", advert.getLocation());
                Intent appInfo = new Intent(ShowAdvertsActivity.this, RemoveActivity.class);
                appInfo.putExtras(bundle);
                startActivity(appInfo);
            }
        });
    }
}