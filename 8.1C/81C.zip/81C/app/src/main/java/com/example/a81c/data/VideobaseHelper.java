package com.example.a81c.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.a81c.User.Video;
import com.example.a81c.util.Util;

import java.util.ArrayList;
import java.util.List;

public class VideobaseHelper extends SQLiteOpenHelper {
    public VideobaseHelper(@Nullable Context context) {
        super(context, Util.VIDEOTABLE_NAME, null, Util.DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        String CREATE_USER_TABLE = "CREATE TABLE " + Util.VIDEOTABLE_NAME + "(" + Util.PLAYLIST + " INTEGER, " + Util.LINK + " TEXT" + ");";

        sqLiteDatabase.execSQL(CREATE_USER_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        String DROP_USER_TABLE = "DROP TABLE IF EXISTS ";
        sqLiteDatabase.execSQL(DROP_USER_TABLE + Util.VIDEOTABLE_NAME);

        onCreate(sqLiteDatabase);
    }

    public List<Video> FetchAllVideo (int clientid) {
        List<Video> videoList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String selectAll = " SELECT * FROM " + Util.VIDEOTABLE_NAME + " Where " +  Util.PLAYLIST + " = " + clientid;
        // Allow the cursor to access all rows of data
        Cursor cursor = db.rawQuery(selectAll, null);
        if (cursor.moveToFirst()) {
            do {
                // Get all information for current advert
                Video video = new Video();
                video.setClientid(cursor.getInt(0));
                video.setPlaylist(cursor.getString(1));


                // Add to advertList
                videoList.add(video);

            } while (cursor.moveToNext()); //Iterate while there is another advert
        }

        return videoList;
    }

    public long insertVideo (Video video)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Util.PLAYLIST, video.getClientid());
        contentValues.put(Util.LINK, video.getPlaylist());

        long newRowId = db.insertOrThrow(Util.VIDEOTABLE_NAME, null, contentValues);
        db.close();
        return newRowId;
    }
}
