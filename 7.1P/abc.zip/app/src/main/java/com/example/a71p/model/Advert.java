package com.example.a71p.model;

public class Advert {
    private int advert_id;
    private String name;
    private String description;
    private String location;
    private String type;
    private String phone;
    private String date;


    public Advert(String name, String description, String location, String phone, String date, String type) {
        this.name = name;
        this.description = description;
        this.location = location;
        this.phone = phone;
        this.date = date;
        this.type = type;
    }

    public Advert() {
    }

    public int getAdvert_id() { return advert_id;}

    public void setAdvert_id(int advert_id) {this.advert_id = advert_id;}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
