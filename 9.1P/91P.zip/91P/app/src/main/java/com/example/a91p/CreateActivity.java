package com.example.a91p;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.a91p.data.DatabaseHelper;
import com.example.a91p.model.Advert;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.AutocompleteSupportFragment;
import com.google.android.libraries.places.widget.listener.PlaceSelectionListener;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import pub.devrel.easypermissions.AfterPermissionGranted;
import pub.devrel.easypermissions.AppSettingsDialog;
import pub.devrel.easypermissions.EasyPermissions;

public class CreateActivity extends AppCompatActivity {

    private static final String TAG = "Running";
    LocationManager locationManager;
    LocationListener locationListener;

    // Create variable for requesting permission
    private final int REQUEST_LOCATION_PERMISSION = 123;




    //Initialize advertLoc
    public String advertLoc = "If this is here, no location was selected!";
    public double advertLat = 1;
    public double advertLong = 1;
    DatabaseHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);
        RadioGroup radioGroup = findViewById(R.id.radioGroup);
        Button saveButton = findViewById(R.id.saveButton);
        Button currentLocBtn = findViewById(R.id.currentLocBtn);
        EditText nameText = findViewById(R.id.nameText);
        EditText descText = findViewById(R.id.descText);
        EditText phoneText = findViewById(R.id.phoneText);
        EditText date = findViewById(R.id.dateSelect);


        db = new DatabaseHelper(getApplicationContext());

        // Initialize Places SDK
        Places.initialize(getApplicationContext(), "AIzaSyB7qYxILfrXYcz0ITKD-_hvIznVNYI6TlA");

        // Create instance of PlacesClient
        PlacesClient placesClient = Places.createClient(this);

        // Initialize the AutocompleteSupportFragment.
        AutocompleteSupportFragment autocompleteFragment = (AutocompleteSupportFragment)
                getSupportFragmentManager().findFragmentById(R.id.locationText);

        // Specify the types of place data to return.
        autocompleteFragment.setPlaceFields(Arrays.asList(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG));

        // Set up a PlaceSelectionListener to handle the response.
        autocompleteFragment.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(@NonNull Place place) {
                // TODO: Get info about the selected place.
                advertLoc = place.getName();
                advertLat=place.getLatLng().latitude;
                advertLong=place.getLatLng().longitude;
            }


            @Override
            public void onError(@NonNull Status status) {
                // TODO: Handle the error.
                Log.i(TAG, "An error occurred: " + status);
            }
        });



        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String advertType = "Lost";
                int checkedRadioButtonId = radioGroup.getCheckedRadioButtonId();
                // no type is selected
                if (checkedRadioButtonId == -1) {
                    Toast.makeText(CreateActivity.this, "No advert type was selected! ", Toast.LENGTH_SHORT).show();
                }
                else{
                    if (checkedRadioButtonId == R.id.radioButton)
                    {
                        advertType = "Lost";
                    }
                    if (checkedRadioButtonId == R.id.radioButton2)
                    {
                        advertType = "Found";
                    }

                    String advertName = nameText.getText().toString();
                    String advertDesc = descText.getText().toString();
                    String advertPhone = phoneText.getText().toString();
                    String advertDate = date.getText().toString();
                    if(TextUtils.isEmpty(advertName) || TextUtils.isEmpty(advertDesc) || TextUtils.isEmpty(advertLoc) || TextUtils.isEmpty(advertPhone) || TextUtils.isEmpty(advertDate))
                    {
                        Toast.makeText(CreateActivity.this, "Empty field", Toast.LENGTH_SHORT).show();
                    }

                    else
                    {
                        long result = db.insertAdvert(new Advert(advertName, advertDesc, advertLoc, advertPhone, advertDate, advertType, advertLong, advertLat));
                        if (result > 0)
                        {
                            Toast.makeText(CreateActivity.this, "Advert created", Toast.LENGTH_SHORT).show();
                        }
                        else
                        {
                            Toast.makeText(CreateActivity.this, "Advert error", Toast.LENGTH_SHORT).show();
                        }
                    }
                }


            }

        });

        currentLocBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String location = getLocation();
                autocompleteFragment.setText(location);
            }
        });
    }


    public String getLocation (){
        //Initialize LocationManager
        locationManager = (LocationManager) this.getSystemService(LOCATION_SERVICE);
        Location myLocation =locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        String locationName = myLocation.toString();
        return locationName;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Status status = Autocomplete.getStatusFromIntent(data);
        Log.e("Test", status.toString());
    }

}