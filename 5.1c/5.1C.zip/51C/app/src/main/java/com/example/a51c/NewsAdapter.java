package com.example.a51c;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.ViewHolder>
{

    private List<News> newsList;
    private Context context;
    private NewsNoteListener newsNoteListener;

    public NewsAdapter(List<News> newsList, Context context, NewsNoteListener newsNoteListener) {
        this.newsList = newsList;
        this.context = context;
        this.newsNoteListener = newsNoteListener;
    }


    @NonNull
    @Override
    public NewsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context)
                .inflate(R.layout.news_row2, parent, false);
        return new ViewHolder(itemView, newsNoteListener);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.newsTitle2.setText(newsList.get(position).getNewsTitle());
        holder.newsLogo2.setImageResource(newsList.get(position).getNewsLogo());
        holder.newsDescription2.setText(newsList.get(position).getNewsDescription());
    }

    @Override
    public int getItemCount() {
        return newsList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public ImageView newsLogo2;
        public TextView newsTitle2, newsDescription2;


        NewsNoteListener newsNoteListener;
        public ViewHolder(@NonNull View itemView, NewsNoteListener newsNoteListener) {
            super(itemView);
            newsTitle2 = itemView.findViewById(R.id.newsTitle2);
            newsLogo2 = itemView.findViewById(R.id.newsLogo2);
            newsDescription2 = itemView.findViewById(R.id.newsDescription2);
            this.newsNoteListener = newsNoteListener;

            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {  newsNoteListener.newsNoteClick(getAdapterPosition()); }

        }
    public interface NewsNoteListener{
        void newsNoteClick(int position);
    }
}
