package com.example.a81c;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.a81c.data.DatabaseHelper;
import com.example.a81c.data.VideobaseHelper;
import com.example.a81c.util.Util;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button newUser = findViewById(R.id.newAdvert);
        Button loginButton = findViewById(R.id.allButton);
        EditText mainUser = findViewById(R.id.mainUser);
        EditText mainPass = findViewById(R.id.mainPass);


        DatabaseHelper db = new DatabaseHelper(getApplicationContext());
        newUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent createIntent = new Intent(MainActivity.this, CreateActivity.class);
                startActivity(createIntent);
            }
        });

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String name = mainUser.getText().toString();
                String pass = mainPass.getText().toString();
                boolean result = db.fetchUser(name, pass);
                if (result == true)
                {
                    Toast.makeText(MainActivity.this, "Successfully logged in", Toast.LENGTH_SHORT).show();
                    Intent allIntent = new Intent(MainActivity.this, HomeActivity.class);
                    allIntent.putExtra("username", name);
                    startActivity(allIntent);
                }
                else
                {
                    Toast.makeText(MainActivity.this, "The user does not exist", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}