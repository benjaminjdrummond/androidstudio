package com.example.a81c;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.a81c.data.DatabaseHelper;

public class RemoveActivity extends AppCompatActivity {

    TextView removeName, removePhone, removeDate, removeLoc, removeDesc;
    Button removeButton;
    DatabaseHelper db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remove);

        removeName = findViewById(R.id.removeName);
        removePhone = findViewById(R.id.removePhone);
        removeDate = findViewById(R.id.removeDate);
        removeLoc = findViewById(R.id.removeLoc);
        removeButton = findViewById(R.id.removeButton);
        removeDesc = findViewById(R.id.removeDesc);

        //Get Bundle
        Bundle bundle = getIntent().getExtras();

        //Extract data
        int advertId = bundle.getInt("id");
        String advertName = bundle.getString("name");
        String advertDesc = bundle.getString("desc");
        String advertPhone = bundle.getString("phone");
        String advertLoc = bundle.getString("location");
        String advertType = bundle.getString("type");
        String advertDate = bundle.getString("date");

        DatabaseHelper db = new DatabaseHelper(getApplicationContext());

        removeName.setText(advertType + " " + advertName);
        removePhone.setText(advertPhone);
        removeDate.setText(advertDate);
        removeDesc.setText(advertDesc);
        removeLoc.setText(advertLoc);

        removeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                db.deleteRow(advertName);
            }
        });
    }
}