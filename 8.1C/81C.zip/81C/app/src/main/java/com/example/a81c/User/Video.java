package com.example.a81c.User;

public class Video {
    private int clientid;
    private String playlist;

    public Video(int clientid, String playlist) {
        this.clientid = clientid;
        this.playlist = playlist;
    }

    public Video() {
    }

    public int getClientid() {
        return clientid;
    }

    public void setClientid(int clientid) {
        this.clientid = clientid;
    }

    public String getPlaylist() {
        return playlist;
    }

    public void setPlaylist(String playlist) {
        this.playlist = playlist;
    }
}