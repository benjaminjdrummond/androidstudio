package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class QuizActivity extends AppCompatActivity {

    int CurrentProgress = 0;
    int questionAmount;
    int currentCount = 0;
    int currentButton = 0;
    int score = 0;

    boolean answered;

    public ProgressBar progressBar;
    public Button answer1, answer2, answer3, btnSubmit;
    public TextView questionText, questionNum, welcomeUser;

    private List<Questions> questionsList;
    private Questions currentQuestion;

    ColorStateList buttonColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        progressBar = findViewById(R.id.progressBar);
        progressBar.setProgress(CurrentProgress);
        btnSubmit = findViewById(R.id.btnSubmit);
        answer1 = findViewById(R.id.answer1);
        answer2 = findViewById(R.id.answer2);
        answer3 = findViewById(R.id.answer3);
        questionText = findViewById(R.id.questionText);
        welcomeUser = findViewById(R.id.welcomeUser);

        questionNum = findViewById(R.id.questionNum);
        buttonColor = answer1.getTextColors();

        // Get intent
        Intent intent = getIntent();
        Bundle bundle1 = intent.getExtras();
        String userName = bundle1.getString("variable");
        welcomeUser.setText("Welcome " + userName + "!");
        //Create Questions
        questionsList = new ArrayList<>();
        addQuestions();
        questionAmount = questionsList.size();
        nextQuestion();

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (answered == false) {
                    // If the question has not been answered, check if correct
                    if (currentButton != 0) {
                        answerCheck();
                    }
                    // Check if
                    else {
                        Toast.makeText(QuizActivity.this, "Please select an answer", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    nextQuestion();

                }
                String checkFinish = btnSubmit.getText().toString();
                if(checkFinish.equals("Finish")){
                    Intent intent2 = new Intent(getApplicationContext(), QuizEnd.class);
                    String nameOfUser = userName;
                    int scoreOfUser = score;
                    intent2.putExtra("username", nameOfUser);
                    intent2.putExtra("score", scoreOfUser);
                    startActivity(intent2);
                    finish();
                }
            }
        });

        //Set Current Button
        answer1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentButton = 1;
                answer1.setBackgroundColor(Color.GREEN);
                answer2.setBackgroundColor(808080);
                answer3.setBackgroundColor(808080);
            }
        });

        answer2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentButton = 2;
                answer1.setBackgroundColor(808080);
                answer2.setBackgroundColor(Color.GREEN);
                answer3.setBackgroundColor(808080);
            }
        });

        answer3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentButton = 3;
                answer1.setBackgroundColor(808080);
                answer2.setBackgroundColor(808080);
                answer3.setBackgroundColor(Color.GREEN);
            }
        });
    }

    private void answerCheck(){
        answered = true;
        answer1.setBackgroundColor(Color.RED);
        answer2.setBackgroundColor(Color.RED);
        answer3.setBackgroundColor(Color.RED);
        if(currentButton == currentQuestion.getCorrectAnsNo())
        {
            score++;
        }
        switch (currentQuestion.getCorrectAnsNo()){
            case 1:
                answer1.setBackgroundColor(Color.GREEN);
                break;
            case 2:
                answer2.setBackgroundColor(Color.GREEN);
                break;
            case 3:
                answer3.setBackgroundColor(Color.GREEN);
                break;
        }
        if(currentCount < questionAmount){
            btnSubmit.setText("Next");
        }
        else{
            btnSubmit.setText("Finish");
        }
    }



    //Add questions by inserting to the end of a list
    private void addQuestions() {
        questionsList.add(new Questions("Is android open source?", "Trick Question", "No", "Yes.", 3));
        questionsList.add(new Questions("Does android rely on the linux kernel for core services?", "Yes", "What is linux", "No", 1));
        questionsList.add(new Questions("Which is not a widget in android studio?", "CheckBox", "Spinner", "Import", 3));
        questionsList.add(new Questions("What is not a programmable language supported by android studio?", "Java", "Assembly", "Kotlin", 2));
        questionsList.add(new Questions("Does an activity provide the user a screen with which they can interact/view?", "Yes", "No", "Trick Question", 1));
        questionsList.add(new Questions("Is it possible to have multiple activities in an app?", "Yes", "No", "Maybe", 1));
        questionsList.add(new Questions("How many possible lifecycle states are there for an activity?", "3", "4", "5", 2));
        questionsList.add(new Questions("Does IDE stand for Integrated Development Environment?", "Yes", "Maybe", "No", 1));
        questionsList.add(new Questions("What type of layout aligns its contents into a single direction, vertical or horizontal?", "Shared", "Relative", "Linear", 3));
        questionsList.add(new Questions("Does padding or margin deal with the space between a border and a parent layout", "Margin", "Padding", "Neither", 1));
    }

    private void nextQuestion() {

        // Reset colours for new question
        answer1.setBackgroundColor(808080);
        answer2.setBackgroundColor(808080);
        answer3.setBackgroundColor(808080);
        if(currentCount  < questionAmount){
            currentQuestion = questionsList.get(currentCount);
            questionText.setText(currentQuestion.getQuestion());
            answer1.setText(currentQuestion.getAnswer1());
            answer2.setText(currentQuestion.getAnswer2());
            answer3.setText(currentQuestion.getAnswer3());
            answer1.setTextColor(buttonColor);
            currentCount++;
            btnSubmit.setText("Submit");
            questionNum.setText(currentCount + "/" + questionAmount);
            // Set boolean to false, so that we can turn true later
            answered = false;
            currentButton = 0;

            // Move progress bar
            CurrentProgress = CurrentProgress + 10;
            progressBar.setProgress(CurrentProgress);
            progressBar.setMax(100);
        }
    }
}