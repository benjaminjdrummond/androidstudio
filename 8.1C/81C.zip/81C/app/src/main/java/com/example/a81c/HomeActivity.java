package com.example.a81c;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.a81c.User.User;
import com.example.a81c.User.Video;
import com.example.a81c.data.DatabaseHelper;
import com.example.a81c.data.VideobaseHelper;
import com.example.a81c.util.Util;

public class HomeActivity extends AppCompatActivity {


    int playlistnum = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        EditText urlText = findViewById(R.id.urlText);

        Button playButton = findViewById(R.id.playButton);
        Button addButton = findViewById(R.id.addButton);
        Button gotoButton = findViewById(R.id.gotoButton);

        VideobaseHelper db = new VideobaseHelper(getApplicationContext());
        DatabaseHelper dbz = new DatabaseHelper(getApplicationContext());

        Intent intent = getIntent();
        String usersName = intent.getStringExtra("username");
        String queryString = "SELECT * FROM " + Util.TABLE_NAME + " WHERE " + Util.NAME +  "= '" + usersName +"'";
        Cursor cursor = dbz.getReadableDatabase().rawQuery(queryString, null);
        if(cursor.moveToFirst()) {
            playlistnum = cursor.getInt(0);
        }

        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent createIntent = new Intent(HomeActivity.this, PlayActivity.class);
                createIntent.putExtra("link", urlText.getText().toString());
                startActivity(createIntent);
            }
        });

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String videoLink = urlText.getText().toString();
                if(TextUtils.isEmpty(videoLink))
                {
                    Toast.makeText(HomeActivity.this, "Empty field", Toast.LENGTH_SHORT).show();

                }
                 else
                {
                    long result = db.insertVideo(new Video(playlistnum, videoLink));
                    if (result > 0)
                    {
                        Toast.makeText(HomeActivity.this, "Video added", Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        Toast.makeText(HomeActivity.this, "Adding error", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        gotoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent createIntent = new Intent(HomeActivity.this, ShowPlaylist.class);
                createIntent.putExtra("clientid", playlistnum);
                startActivity(createIntent);
            }
        });
    }
}