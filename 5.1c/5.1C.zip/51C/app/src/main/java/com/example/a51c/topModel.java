package com.example.a51c;

import android.graphics.drawable.Drawable;

public class topModel {
    private int id;
    private String topName;
    private int topLogo;

    public topModel(int id, int topLogo, String topName)
    {
        this.id = id;
        this.topLogo = topLogo;
        this.topName = topName;
    }
    public int getId() {
        return id;
    }

    public void setId (int id) {
        this.id = id;
    }
    public int getTopLogo() {
        return topLogo;
    }

    public String getTopName() {
        return topName;
    }

    public void setTopLogo (int topLogo) {
        this.topLogo = topLogo;
    }

    public void setTopName (String topName) {
        this.topName = topName;
    }
}
