package com.example.a51c;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements com.example.a51c.topNewsAdapter.OnNoteListener, NewsAdapter.NewsNoteListener {

    RecyclerView topView, newsView;
    topNewsAdapter topNewsAdapter;
    NewsAdapter newsAdapter;
    List<News> newsList = new ArrayList<>();
    List<topModel> topList = new ArrayList<>();

    // In order
    // Depp, Eg, Elon, Jetstream, Miles, EUM, ES6, Randy, Armstrong, Backlash, MSI, MGRR, Bleach, AOT
    //Create Integer and String arrays for top recycler view
    int[] topLogo = {R.drawable.depp, R.drawable.eg, R.drawable.elon, R.drawable.jetstream, R.drawable.miles};
    String[] topName = {"Depp", "Eg", "Elon", "Jetstream", "Miles"};

    //Create Integer and String arrays for news recycler view
    int[] newsLogo = {R.drawable.eum, R.drawable.es6, R.drawable.randy, R.drawable.armstrong, R.drawable.backlash, R.drawable.msi, R.drawable.mgrr, R.drawable.bleach, R.drawable.aot};
    String[] newsTitle = {"EUMasters playoffs", "ES6 Date Leaked", "20 Years of Randy", "Armstrongs Election", "Wrestlemania Backlash", "MSI groups announced", "MGRR 2", "Bleach Return", "AOT S4P3"};
    String[] newsDescription = {"The EUMasters playoffs have been announced after some dominant performances. Notable quarterfinals include: + Karmine Corp Vs UOL and LDLC vs X7"
    , "The release date for The Elder Scrolls 6 is reportedly in late 2025-early 2026, fans are not very happy about this, but are still eager for the new addition.",
    "Randy Orton from WWE has recently achieved 20 active years in the company. Fans and talent praise his hard work ethic over the years. Randy himself claims 'I am the happiest i've ever been."
    , "Senator Armstrong is pushing to become the US President by taking over office from Joe Biden. He plans to have the strong be in charge of anything. The country is in uproar but multiple polls highlight his evergrowing popularity. Armstrong had this to say to reporters. 'I'm making the mother of all omelettes. Can't fret over every egg.' "
    , "Cody Rhodes will be having a rematch with Seth Rollins during WWE's Wrestlemania Backlash. In their last match, Cody Rhodes won in a close match.",
    " The groups for Riot Games' MSI event have been announced. Notably, G2 and EG are in the same group, meaning there will be lots of international competition between NA and EU.",
    "Fans eagerly await for the announcement of the sequel to the critically acclaimed Metal Gear Rising: Revengence. So far, no news has been made, and fans are on the shelf if it will even happen.",
    "After taking a 10 year break, the anime known as 'Bleach' by Tite Kubo will be returning with the Thousand-Year Blood War arc. Fans are left wondering how well it will be made given the track record of Studio Pierrot.",
    "Part 3 of the final season to Attack on Titan has been announced recently, and people everywhere are pondering why it was called the final season in the first place. Nevertheless, anticipation is at it's highest after a wonderful season."};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Assign ids for top view
        topView = findViewById(R.id.topView);
        topNewsAdapter = new topNewsAdapter(topList, this, this);
        topView.setAdapter(topNewsAdapter);

        // Assign ids for news
        newsView = findViewById(R.id.newsView);
        newsAdapter = new NewsAdapter(newsList, this, this);
        newsView.setAdapter(newsAdapter);
        newsView.setLayoutManager(new GridLayoutManager(this, 2));

        topView.setLayoutManager(new LinearLayoutManager(this , LinearLayoutManager.HORIZONTAL, false));

        for (int j = 0; j < newsTitle.length; j++){
            News newsModel = new News(j, newsLogo[j], newsTitle[j], newsDescription[j]);
            newsList.add(newsModel);
        }

        for (int i = 0; i < topLogo.length; i++){
            topModel model = new topModel(i, topLogo[i], topName[i]);
                    topList.add(model);
        }
    }
    @Override
    public void onNoteClick(int position) {
            selectTopFragment(position);
        }

    @Override
    public void newsNoteClick(int position) {
            selectNewsFragment(position);
    }
    // Depp, Eg, Elon, Jetstream, Miles, EUM, ES6, Randy, Armstrong, Backlash, MSI, MGRR, Bleach, AOT
    private void selectTopFragment(int position) {
        Fragment fragment;
        switch(position)
        {
            case 0:
                fragment = new DeppFragment();
                break;
            case 1:
                fragment = new EgFragment();
                break;
            case 2:
                fragment = new ElonFragment();
                break;
            case 3:
                fragment = new JetstreamFragment();
                break;
            case 4:
                fragment = new MilesFragment();
                break;
            case 5:
                fragment = new EumFragment();
                break;
            case 6:
                fragment = new Es6Fragment();
                break;
            case 7:
                fragment = new RandyFragment();
                break;
            case 8:
                fragment = new ArmstrongFragment();
                break;
            case 9:
                fragment = new BacklashFragment();
                break;
            case 10:
                fragment = new MSIFragment();
                break;
            case 11:
                fragment = new MGRRFragment();
                break;
            case 12:
                fragment = new BleachFragment();
                break;
            case 13:
                fragment = new AOTFragment();
                break;

            default:
                throw new IllegalStateException("Unexpected position: " + position);

            }
        // Select fragment for current news item selected
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragmentContainerView, fragment).addToBackStack(null).commit();
    }

    private void selectNewsFragment(int position) {
        Fragment fragment;
        switch(position){
            case 0:
                fragment = new EumFragment();
                break;
            case 1:
                fragment = new Es6Fragment();
                break;
            case 2:
                fragment = new RandyFragment();
                break;
            case 3:
                fragment = new ArmstrongFragment();
                break;
            case 4:
                fragment = new BacklashFragment();
                break;
            case 5:
                fragment = new MSIFragment();
                break;
            case 6:
                fragment = new MGRRFragment();
                break;
            case 7:
                fragment = new BleachFragment();
                break;
            case 8:
                fragment = new AOTFragment();
                break;

            default:
                throw new IllegalStateException("Unexpected position: " + position);
        }
        // Select fragment for current news item selected
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragmentContainerView, fragment).addToBackStack(null).commit();
}


}