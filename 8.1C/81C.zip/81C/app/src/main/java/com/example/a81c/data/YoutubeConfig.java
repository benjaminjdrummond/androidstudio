package com.example.a81c.data;

public class YoutubeConfig {

    public YoutubeConfig() {

    }

    private static final String API_KEY = "AIzaSyCGyU4q3b1YvpJgBwwPXfHFsQOLcTe9MTY";

    public static String getApiKey() {
        return API_KEY;
    }
}
