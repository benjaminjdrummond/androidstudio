package com.example.a71p;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.a71p.data.DatabaseHelper;
import com.example.a71p.model.Advert;

import java.util.Date;

public class CreateActivity extends AppCompatActivity {

    DatabaseHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);
        RadioGroup radioGroup = (RadioGroup)findViewById(R.id.radioGroup);
        Button saveButton = findViewById(R.id.saveButton);
        EditText nameText = findViewById(R.id.nameText);
        EditText descText = findViewById(R.id.descText);
        EditText locText = findViewById(R.id.locationText);
        EditText phoneText = findViewById(R.id.phoneText);
        EditText date = findViewById(R.id.dateSelect);

        db = new DatabaseHelper(getApplicationContext());

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String advertType = "Lost";
                int checkedRadioButtonId = radioGroup.getCheckedRadioButtonId();
                // no type is selected
                if (checkedRadioButtonId == -1) {
                    Toast.makeText(CreateActivity.this, "No advert type was selected! ", Toast.LENGTH_SHORT).show();
                }
                else{
                    if (checkedRadioButtonId == R.id.radioButton)
                    {
                        advertType = "Lost";
                    }
                    if (checkedRadioButtonId == R.id.radioButton2)
                    {
                        advertType = "Found";
                    }

                    String advertName = nameText.getText().toString();
                    String advertDesc = descText.getText().toString();
                    String advertLoc = locText.getText().toString();
                    String advertPhone = phoneText.getText().toString();
                    String advertDate = date.getText().toString();
                    if(TextUtils.isEmpty(advertName) || TextUtils.isEmpty(advertDesc) || TextUtils.isEmpty(advertLoc) || TextUtils.isEmpty(advertPhone) || TextUtils.isEmpty(advertDate))
                    {
                        Toast.makeText(CreateActivity.this, "Empty field", Toast.LENGTH_SHORT).show();
                    }

                    else
                    {
                        long result = db.insertAdvert(new Advert(advertName, advertDesc, advertLoc, advertPhone, advertDate, advertType));
                        if (result > 0)
                        {
                            Toast.makeText(CreateActivity.this, "Advert created", Toast.LENGTH_SHORT).show();
                        }
                        else
                        {
                            Toast.makeText(CreateActivity.this, "Advert error", Toast.LENGTH_SHORT).show();
                        }
                    }
                }


            }
        });
    }
}