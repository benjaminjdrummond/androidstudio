package com.example.a81c;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.a81c.User.Video;
import com.example.a81c.data.DatabaseHelper;
import com.example.a81c.User.User;
import com.example.a81c.data.VideobaseHelper;

import java.util.ArrayList;
import java.util.List;

public class ShowPlaylist extends AppCompatActivity {

    ListView videoListView;
    ArrayList<String> videoArrayList;

    // Implement adapter
    ArrayAdapter<String> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_adverts);

        Intent intent = getIntent();
        int clientid = intent.getIntExtra("clientid", 0);

        videoListView = findViewById(R.id.playlistListView);
        videoArrayList = new ArrayList<>();
        VideobaseHelper db = new VideobaseHelper(getApplicationContext());

        List<Video> videoList = db.FetchAllVideo(clientid);

        // Iterate through advertList
        // Go through by key : value
        for (Video video : videoList)
        {
            videoArrayList.add(video.getPlaylist());
        }

        // Create adapter
        arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, videoArrayList);
        // Set adapter to listview to populate
        videoListView.setAdapter(arrayAdapter);
    }
}