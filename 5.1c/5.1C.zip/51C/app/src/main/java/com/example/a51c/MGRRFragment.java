package com.example.a51c;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link EgFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class MGRRFragment extends Fragment implements RelatedAdapter.RelatedNoteListener {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    RelatedAdapter relatedAdapter;
    private RecyclerView relatedView;
    private List<News> relatedList = new ArrayList<>();
    private int[] relatedLogo = {R.drawable.armstrong, R.drawable.jetstream};
    private String[] relatedName = {"Armstrong's Election", "Sam finds purpose"};
    private String[] relatedDesc = {"Senator Armstrong is pushing to become the US President by taking over office from Joe Biden. He plans to have the strong be in charge of anything. The country is in uproar but multiple polls highlight his evergrowing popularity. Armstrong had this to say to reporters. 'I'm making the mother of all omelettes. Can't fret over every egg.'", "The legendary cyborg samurai has finally found his purpose after all these years. He previously told interviews 'Have I gone insane?'  and that he must realise 'why he fights'. It told reporters that he now fights for fun, and for a heir that can inherit his blade."};

    public MGRRFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment EgFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static MGRRFragment newInstance(String param1, String param2) {
        MGRRFragment fragment = new MGRRFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate layout for this fragment
        View view = inflater.inflate(R.layout.fragment_depp, container, false);
        ImageView imageView = (ImageView) view.findViewById(R.id.fragImage);
        TextView title = (TextView) view.findViewById(R.id.fragTitle);
        TextView desc = (TextView) view.findViewById(R.id.fragDesc);
        imageView.setBackgroundResource(R.drawable.mgrr);
        title.setText("MGRR 2");
        desc.setText("Fans eagerly await for the announcement of the sequel to the critically acclaimed Metal Gear Rising: Revengence. So far, no news has been made, and fans are on the shelf if it will even happen.");

        //Implement data
        for (int j = 0; j < relatedName.length; j++){
            News relatedModel = new News(j, relatedLogo[j], relatedName[j], relatedDesc[j]);
            relatedList.add(relatedModel);

        }
        // Assign ids for news
        relatedView = (RecyclerView) view.findViewById(R.id.relatedView);
        relatedView.setLayoutManager(new LinearLayoutManager(getActivity()));
        relatedAdapter = new RelatedAdapter(relatedList, view.getContext(), this);
        relatedView.setAdapter(relatedAdapter);
        relatedView.setItemAnimator(new DefaultItemAnimator());
        return view;

    }

    @Override
    public void relatedNoteClick(int position) {
        selectFragment(position);
    }

    private void selectFragment(int position) {
        Fragment fragment;
        switch(position)
        {
            case 0:
                fragment = new ArmstrongFragment();
                break;
            case 1:
                fragment = new JetstreamFragment();
                break;
            default:
                throw new IllegalStateException("Unexpected position: " + position);

        }
        // Select fragment for current news item selected
        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragmentContainerView, fragment).addToBackStack(null).commit();
    }
}